/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package principal;

import classes.GeradorLog;
import classes.Microondas;
import java.io.FileWriter;
import java.io.IOException;
import java.util.InputMismatchException;
import java.util.Scanner;

/**
 * Classe principal onde se localiza o método "main" que fará uso
 * dos métodos da classe "Microondas"
 * @author Marlon Duarte - 493408
 * @version 02.04.2021
 */
public class Principal {

    public static void main(String[] args) throws IOException{
        int opc = 0;
        GeradorLog g = new GeradorLog();
        Scanner sc = new Scanner(System.in);
        System.out.println("Microodas");
        Microondas consul = new Microondas();
        
        try {
            do { 
                try{
                    System.out.println("Menu de opções!");
                    System.out.println("1 - Ligar");
                    System.out.println("2 - Ligar com tempo definido");
                    System.out.println("3 - Ajustar Potência");
                    System.out.println("4 - Menus Pratos");
                    System.out.println("5 - Sair");
                    System.out.println("opção: ");
                    opc = sc.nextInt();

                    switch (opc){
                        case 1:
                            consul.setLigar();
                            g.escerverLog("opção 1 - ligar", false);
                            g.escerverLog("Método setLigar()", false);
                            break;
                        case 2:
                            System.out.println("Digite o tempo: ");
                            try {
                                int o = sc.nextInt();
                                String msn = Integer.toString(o);
                                consul.setLigar(o);
                                g.escerverLog("opção 2 - ligar com tempo definido em " + msn + " segundos.", false);
                                g.escerverLog("Método setLigar(int tempo)", false);
                            }catch (NullPointerException e){
                                System.err.println(e.getMessage());
                                g.escerverLog(e.getMessage(), false);
                            }
                            break;
                        case 3:
                            System.out.println("Digite a potencia: ");
                            try{
                                int o = sc.nextInt();
                                String msn = Integer.toString(o);
                                consul.setPotencia(o);
                                g.escerverLog("Alterar potência para "+ msn, false);
                                g.escerverLog("Método setPotencia()", false);
                            }catch (NullPointerException e){
                                System.err.println(e.getMessage());
                                g.escerverLog(e.getMessage(), false);
                            }
                            break;
                        case 4:
                            System.out.println("Opções predefinidas: ");
                            System.out.println("1 - Alimento 1; ");
                            System.out.println("2 - Alimento 2; ");
                            int o = sc.nextInt();
                            String msn = Integer.toString(o);
                            consul.preDefinido(o);
                            g.escerverLog("Opções predefinidas - escolha " + msn, false);
                            g.escerverLog("Método preDefinido()", false);
                            break;
                        case 5:
                            g.escerverLog("Saida do menu!", false);
                            g.escerverLog("Programa finalizado com Sucesso", true);
                            System.out.println("Programa finalizado com Sucesso");
                            return;
                        default:
                            System.out.println("Código inválido!");
                            g.escerverLog("Código inválido", false);
                            break;
                    }
                }catch (InputMismatchException e){
                    System.err.println("Caracter inválido!");
                    g.escerverLog("InputMismatchException - caracter inválido", false);
                    limparBuffer(sc);

                }

            } while (opc != 5);
        } catch (IOException e){
            System.err.println("Erro ao escrever arquivo de Log!");
        }
        
    }
    
    private static void GeradorLog(String toString, boolean b) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
    private static void limparBuffer(Scanner leitor) {
        if (leitor.hasNextLine()) {
            leitor.nextLine();
        }
    }
}