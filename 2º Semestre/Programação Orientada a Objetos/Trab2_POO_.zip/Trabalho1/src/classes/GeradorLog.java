/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package classes;

import java.io.FileWriter;
import java.io.IOException;
import java.util.Date;

/**
 *A classe GeradorLog tem a tarefa de gerar um arquivo de log que mostrará
 * os passos escolhidos pelo usuário, bem como os erros percebidos durante 
 * a execução.
 * @author Marlon Duarte - 493408
 * @version 02.04.2021
 */
public class GeradorLog {
    Date data = new Date();
    FileWriter escritor;
    public GeradorLog() throws IOException {
        this.escritor = new FileWriter ("Log - " + data);
        System.out.println("Arquivo de Log iniciado!");
    }
    
    /**
     * Escreve dados de escolha do usuário no menu e em parâmetros,
     * a chamada de métodos e o disparo de exceções no arquivo de log gerado.
     * @param mensagem String com mensagem a ser registrada
     * @param fechar finaliza o arquivo de log
     * @throws IOException Dispara uma exceção se houver falha na escrita do log
     */    
    public void escerverLog(String mensagem, boolean fechar) throws IOException {
        escritor.write(mensagem);
        escritor.write('\n');
        
        if (fechar == true){
            escritor.close();
        }
    }
    
}
