/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package classes;

/**
 *A classe Microondas funciona como uma simulação de um
 * forno microondas simples. É possível através dessa classe
 * ligar e desligar o forno, alterar sua potência e o tempo de 
 * trabalho.
 * @author Marlon Duarte - 493408
 * @version 02.04.2021
 */
public class Microondas {
    private boolean status;
    private int potencia;
    private int tempo;
    public Microondas() {
        this.status = false;
        this.potencia = 100;
        this.tempo = 0;
    }
    
    /**
     * Altera o valor da potência do microondas após fazer uma
     * verificação no atributo "status" bem como no parâmetro "novaPotencia".
     * Que tratará uma exceção caso o valor de novaPotencia seja nulo ou menos
     * que zero.
     * @param novaPotencia Novo valor para a potência.
     */
    public void setPotencia(int novaPotencia) {
        if (novaPotencia <= 0){
            throw new NullPointerException("Parâmetro nulo em setPotência.");
        }else{
            if ((novaPotencia >= 10) && (novaPotencia <= 100)){
                if (status == false){ //LEMBRAR DE AJUSTAR ESSA PARTE
                    this.potencia = novaPotencia;
                } else
                    System.out.println("Erro!!!");
            }else{
                System.out.println("Valor inválido!!!");
            }
        }
         
    }        
    
    
    /**
     * Altera o status para false que significa dizer que desligou
     * o forno microondas, além de settar potência para 100.
     */
    public void setDesligar() {
        setPotencia(100);
        this.status = false;
    }

    /**
     * Liga o microondas por 30 segundos e desliga ao final da execução da tarefa.
     */
    public void setLigar() {
        this.status = true;
        this.tempo = 30;
        System.out.println("Potência: " + potencia );
        for (int i=tempo;i>0;i--){ //Usado para simular o tempo em decremento
            System.out.println("Ligado por "+ i + " segundos!");
                try { 
                    Thread.sleep (1000); 
                } 
                catch (InterruptedException ex){
                }
            System.out.println(" ");
        }
        setDesligar();
        System.out.println(" ");

    }
    
    /**
     * Liga o microondas por um valor de tempo que deve ser informado pelo usuário. 
     * Possui uma exceção para valores nulos ou negativos.
     * @param tempo Tempo de execução de tarefa do microondas
     */
    public void setLigar(int tempo) {
        this.status = true;
        if (tempo <= 0){
            throw new NullPointerException("Parâmetro nulo ou negativo para tempo!");
        }else{
            this.tempo = tempo;
            System.out.println("Potência: " + potencia );
            for (int i=tempo;i>0;i--){ //Usado para simular o tempo em decremento
                System.out.println("Ligado por "+ i + " segundos!");
                    try { 
                        Thread.sleep (1000); 
                    } 
                    catch (InterruptedException ex){
                    }
                System.out.println(" ");
            }
            setDesligar();
        }
    }
    
    /**
     * Método com predefinições para um determinado tipo de 
     * alimento que necessita de 600 segundos e potência em 90
     * para ser preparado. Após a execução, ele desliga.
     */
    private void alimento1(){
        System.out.println("Alimento 1");
        this.status = true;
        setPotencia(90);
        System.out.println("Vamos organizar as coisas!!!");
        System.out.println("Já que isso é uma simulação, vamos dar uma acelerada");
        System.out.println("E trocar os 600 segundos para 6.");
        System.out.println("Ficar 10 minutos esperando a execução para ver o log no final é demais!!! KKKK");
        setLigar(6); //Deveria ter 600;
        setDesligar();
    }
    
    /**
     * Método com predefinições para um determinado tipo de 
     * alimento que necessita de 900 segundos e potência em 80
     * para ser preparado. Após a execução, ele desliga
     */
    private void alimento2(){
        System.out.println("Alimento 2");
        this.status = true;
        setPotencia(80);
        System.out.println("Vamos organizar as coisas!!!");
        System.out.println("Já que isso é uma simulação, vamos dar uma acelerada");
        System.out.println("E trocar os 900 segundos para 9.");
        System.out.println("Ficar 15 minutos esperando a execuçãopara ver o log no final é demais!!! KKKK");
        setLigar(9); //Deveria ter 900;
        setDesligar();
    }
    
    /**
     * Oferece opções predefinidas através de um menu para os métodos
     * privados "alimento1" e "alimento2" e retorna mensagem de erro caso 
     * a opção escolhida não corresponda às predefinições dos métodos.
     * @param escolha Opção a ser escolhida para uma das predefinições
     */
    public void preDefinido(int escolha){
        switch (escolha) {
            case 1:
                alimento1();
                break;
            case 2:
                alimento2();
                break;
            default:
                System.out.println("Escolha inávlida!");
                break;
        }
    }
}
