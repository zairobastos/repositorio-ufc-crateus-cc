#ifndef ESFERA_H_INCLUDED
#define ESFERA_H_INCLUDED

float raio, pi;
float volume_esfera(float raio, float pi);
float area_esfera(float raio, float pi);
float raio_esfera_volume(float volume, float pi);
float raio_esfera_area(float area, float pi);

#endif // ESFERA_H_INCLUDED
