
typedef struct cubo Cubo;

Cubo* criaCubo();

float getaresta(Cubo* cubo);
void setaresta(Cubo* cubo,float aresta);

float area(Cubo* cubo);
float volume(Cubo* cubo);
float tamanho(Cubo* cubo);
