

typedef struct circulo Circulo;

Circulo* criaCirculo();

float getraio(Circulo* circulo);
void setraio(Circulo* circulo,float raio);
float comprimento(Circulo* circulo);
float area(Circulo* circulo);
