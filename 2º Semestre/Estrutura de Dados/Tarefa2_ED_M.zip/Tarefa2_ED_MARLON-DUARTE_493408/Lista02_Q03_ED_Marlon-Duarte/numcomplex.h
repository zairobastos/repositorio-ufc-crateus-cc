void cria (float x, float y);
void apaga (float x, float y);
void soma (float x1, float y1, float x2, float y2);
void subtrai(float x1, float y1, float x2, float y2);
void multiplica(float x1, float y1, float x2, float y2);


