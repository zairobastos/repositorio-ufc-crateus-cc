float circumferencia (float pi, float raio);
float area (float pi, float raio);
