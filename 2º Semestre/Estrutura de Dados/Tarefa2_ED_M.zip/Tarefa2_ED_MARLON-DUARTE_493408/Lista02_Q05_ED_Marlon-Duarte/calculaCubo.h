void medida(float lado);
float area(float lado);
float volume(float lado);
