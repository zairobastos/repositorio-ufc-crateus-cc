


#1)	Desenvolva uma consulta utilizando: 
#a)	SELECT / FROM / WHERE 

#Selecione o nome de todos os clientes que possuem o limite do cartão de crédito 
#superior a 15000.

select nome from conta where id_conta in (
select conta_id_conta from cartao_credito where limite > 15000);


#2)	Desenvolva uma consulta utilizando:
#a)	SELECT / FROM / WHERE / AND

#Selecione o nome do cliente, a Categoria e o Status de todas as despesas onde o valor é 
#superior a 500 e a forma de pagamento é crédito.

select C.nome, D.categoria, D.estatus 
	from conta C, despesa D
	where C.id_conta = D.conta_id_conta
    and 
    (D.valor > 500 and f_pagamento ="CRÉDITO");


#3)	Desenvolva uma consulta utilizando:
#a)	SELECT / AS / FROM 

#Selecione o nome de todos os Usuários da conta

select nome AS NomeClientes from conta;


#4)	Desenvolva uma consulta utilizando:
#a)	SELECT / FROM / WHERE / IS NULL

#Selecione o nome e o email de todos os usuários que não definiram um avatar para a sua conta.

select nome, email from conta where avatar IS NULL;


#5)	Desenvolva uma consulta utilizando:
#a)	SELECT / DISTINCT / FROM

#Selecione todas as categorias (Distintas) que existe em despesas.

SELECT DISTINCT categoria FROM despesa;


#6)	Desenvolva uma consulta utilizando:
#a)	UNION

#Liste todos os ids das contas dos clientes que possuem uma despesa de 
#cartão de credito maior que 800 ou que tenha uma despesa menor 500 no cartão de debito.

select conta_id_conta from despesa, conta  where valor > 800 and f_pagamento="CRÉDITO"
UNION
select conta_id_conta from despesa, conta  where valor < 500 and f_pagamento="DEBITO";


#7)	Desenvolva uma consulta utilizando:
#a)	LIKE

#Selecione todas as despesas que possuem o nome da categoria iniciado com a letra “C”

select * from despesa where categoria like 'C%';


#8)	Desenvolva uma consulta utilizando:
#a)	ORDER BY / ASC
#Liste todos os cartões de débito em ordem crescente pelo valor atual

select * from cartao_debito order by valor_atual asc;

#9)	Desenvolva uma consulta utilizando:

#a)	ORDER BY / DESC
#Liste todos os nomes da conta de forma decrescente

select nome from conta order by nome desc;


#10)	Desenvolva uma consulta utilizando:
#a)	ALL

#Liste todos os números de cartões de crédito e seus respectivos limites, na qual o 
#limite seja maior que todos os cartões de crédito que posssuem limite menor que 15000

SELECT n_cartao_credito, limite FROM cartao_credito
WHERE limite > ALL
(SELECT limite FROM  cartao_credito WHERE (limite < 15000));


#11)	Desenvolva uma consulta utilizando:
#a)	SOME
#Selecione o valor, a categoria e a forma de pagamento de todas as despesas que não foram pagas.

select valor, categoria, f_pagamento from despesa where estatus <> some
(select estatus from despesa where estatus="PAGO" );



#12)	Desenvolva uma consulta utilizando:
#a)	EXISTS
#Liste todas as despesas em que a forma de pagamento seja crédito

select * from despesa des where EXISTS 
(select * from despesa_credito des_c 
where des_c.despesa_data_cod_despesa = des.despesa_data_cod_despesa);

#13)	Desenvolva uma consulta utilizando:
#a)	NOT EXISTS
#Selecione o nome de todos os clientes que possuem receita maior 500

SELECT Nome FROM conta C
WHERE NOT EXISTS
(SELECT * FROM despesa D  WHERE C.id_conta = D.conta_id_conta and valor < 500);

#14)	Desenvolva uma consulta utilizando:
#a)	JOIN

#Recupere o nome de todos os clientes que possuem cartão de credito com limite acima de 15000.

SELECT C.Nome
FROM (conta C JOIN cartao_credito CC ON
c.id_conta=CC.conta_id_conta)
WHERE CC.limite > 15000;


#15)	Desenvolva uma consulta utilizando:
#a)	LEFT OUTER JOIN

#Liste o valor, categoria, a forma de pagamento, e o ano de todas as despesas e
#ordene em ordem crescente por ano.

SELECT valor, categoria, f_pagamento, ano
FROM (despesa LEFT OUTER JOIN despesa_data ON
conta_id_conta=cod_despesa) group by ano asc;


#16)	Desenvolva uma consulta utilizando:
#a)	RIGHT OUTER JOIN

#Liste todas datas das receitas e mostre somente as que possuem estatus PAGO 

select  
des_da.cod_despesa,  
des_da.dia, 
des_da.mes,  
des_da.ano,  
des.despesa_data_cod_despesa,  
des.valor,  
des.categoria,   
des.descricao, 
des.f_pagamento, des.num_cartao,  des.estatus  from 
( despesa des RIGHT OUTER JOIN despesa_data des_da ON des.despesa_data_cod_despesa=des_da.cod_despesa and des.estatus="PAGO");


#17)	Desenvolva uma consulta utilizando:
#a)	CROSS JOIN

#Liste todas as contas e o valor de suas respectivas receitas

SELECT conta.nome, receita.total
FROM (receita CROSS JOIN conta) where receita.conta_id_conta = conta.id_conta;

#18)	Desenvolva uma consulta utilizando:

#a)	COUNT

#Verifique quantos usuários tem cartão de debito com a bandeira VISA

SELECT COUNT(*) AS Total_De_Clientes_BandeiraVisa
 FROM cartao_debito WHERE bandeira= "VISA";

#19)	Desenvolva uma consulta utilizando:
#a)	MIN

#Selecione o menor valor total da receita.

select  min(total) from receita;


#20)	Desenvolva uma consulta utilizando:
#a)	MAX

#Selecione o maior limite dos cartões de crédito

select max(limite) from cartao_credito;


#21)	Desenvolva uma consulta utilizando:
#a)	AVG

#Selecione a média do valor das receitas dos usuários

select avg(total) from receita;

#22)	Desenvolva uma consulta utilizando:
#a)	CASE

#Selecione o número e a bandeira do cartão de credito em que 
#se a fatura for menor ou igual a 200 o cliente gasta pouco, 
#maior que 200 e menor que 1000 gasto intermediário, 
#e maior ou igual a 1000 gasta muito. 

SELECT n_cartao_credito, bandeira,
 CASE
	WHEN valor_fatura <= 200 THEN 'Gasta Pouco'
	WHEN valor_fatura>200 and valor_fatura<1000 THEN 'Gasto Intermediario'
	WHEN valor_fatura>=1000 THEN 'Gasta Muito'
 END AS Gastos FROM cartao_credito;



































































































































