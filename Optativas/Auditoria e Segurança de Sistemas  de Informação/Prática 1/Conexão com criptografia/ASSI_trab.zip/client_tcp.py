#Cliente TCP
import socket

from cryptography.fernet import Fernet

# key = Fernet.generate_key()
# print(key)
f = Fernet("2HfGxIYHljT3mvMuvYPjVRo-ERgM7j_FUOgWouH2b70=")

# Endereco IP do Servidor
SERVER = '127.0.0.1'
# Porta que o Servidor esta escutando
PORT = 3002
tcp = socket.socket(socket.AF_INET,
socket.SOCK_STREAM)
dest = (SERVER, PORT)
tcp.connect(dest)
print ('Para sair digite sair e enter\n')
msg = input()
while msg != 'sair':
    msg = f.encrypt(msg.encode())
    print("Mensagem criptografada", msg)
    print(f.decrypt(msg))
    tcp.send(msg)
    msg = input()
tcp.close()
