#Servidor TCP
import socket
from cryptography.fernet import Fernet

# key = Fernet.generate_key()
# print(key)
f = Fernet("2HfGxIYHljT3mvMuvYPjVRo-ERgM7j_FUOgWouH2b70=")

# Endereco IP do Servidor
HOST = ''
# Porta que o Servidor vai escutar
PORT = 3002
print("executando!")
tcp = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
orig = (HOST, PORT)
tcp.bind(orig)
tcp.listen(1)
while True:
    con, cliente = tcp.accept()
    print ('Concetado por ', cliente)
    while True:
        msg = con.recv(1024)
        if not msg: break
        print(f.decrypt(msg))
    print ('Finalizando conexao do cliente', cliente)
    con.close()
