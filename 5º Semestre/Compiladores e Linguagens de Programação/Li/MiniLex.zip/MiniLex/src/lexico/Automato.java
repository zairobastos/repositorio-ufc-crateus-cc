package lexico;

public enum Automato {
	IDENTIFICADOR, OPERADOR, ERRO
}
