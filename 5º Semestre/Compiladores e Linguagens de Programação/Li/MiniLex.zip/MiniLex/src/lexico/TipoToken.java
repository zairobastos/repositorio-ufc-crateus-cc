package lexico;

public enum TipoToken {
	OPMAIOR, OPMENOR, OPIGUAL,OPMENORIGUAL,
	OPMAIORIGUAL, IDTIPO, IDVAR, EOF, ERRO;
	
	
}
